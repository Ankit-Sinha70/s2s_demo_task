import React from 'react';
import logo from './logo.svg';
import './App.css';
import NavBar from './component/NavBar';
import APPRoute from './component/AppRoute';


function App() {
  return (
    <>
      <NavBar/>
     <APPRoute/>
    </>
      
    
  );
}

export default App;
