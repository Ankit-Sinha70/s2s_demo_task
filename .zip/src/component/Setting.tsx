import React from 'react'
import { Layout } from '@fluentui/react-northstar'
import { Flex, Header, Segment } from '@fluentui/react-northstar';
import { MenuIcon } from '@fluentui/react-icons-northstar';
import { Hd16Filled } from '@fluentui/react-icons';
import { SideBarData } from '../component/SideBarData'
const Setting = () => {
  return (
    <>
    
    <Layout debug start={<h2>this is it</h2>} main={<h1>Hello World</h1>} >
            
    </Layout>
    </>
  )
}

export default Setting;