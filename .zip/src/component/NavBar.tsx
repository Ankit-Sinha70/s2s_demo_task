import * as React from "react";
import { Menu } from "@fluentui/react-northstar";
import { dummyData } from "../data";
import { MenuIcon } from "@fluentui/react-icons-northstar";
import { NavLink } from "react-router-dom";
import { useState } from "react";
import Setting from "./Setting";
import { Button, Dialog } from '@fluentui/react-northstar';

const items = [
  {
    key: "menuItem",
    icon: <MenuIcon />,
    text: "Item 1",
    items: [{ key: "subMenuItem", text: "Sub Item" }, { key: "subMenuItem2" }],
  },
 

  {
    key: "MenuItem1",
    content: "MenuItem1",
    menu: {
      on: "Hover",
      items: [
        { key: "1", content: "item1" },
        {
          key: "2",
          content: "item2",
          menu: [
            {
              key: "1",
              label: "Contact",
              url: "/contact",
              content: "This is some paragraph",
            },
            { key: "2", content: "This is also some paragraph" },
          ],
        },
        {
          key: "3",
          content: "item3",
          menu: [
            { key: "1", content: "item3.1" },
            { key: "2", content: "item3.2" },
          ],
        },
      ],
    },
  },
  {
    key: "editorials",
    content: "MenuItem2",
    menu: {
      items: [
        { key: "1", content: "item1" },
        {
          key: "2",
          content: "item2",
          menu: [
            { key: "1", content: "Hii World This is bla bla bla" },
            { key: "2", content: "Hello universe this is bla bla bla" },
          ],
        },
        {
          key: "3",
          content: "item3",
          menu: [
            { key: "1", content: "This is some card content1" },
            { key: "2", content: "This is some card content2" },
          ],
        },
      ],
    },
  },
  {
    key: "MenuItem3",
    content: "MenuItem3",
    menu: {
      items: [
        { key: "1", content: "item1" },
        {
          key: "2",
          //   icon: <CircleIcon />,
          content: "item2 non augue tortor mollis",
          menu: [
            { key: "1", content: "Hello World" },
            { key: "2", content: "Hello World 2" },
          ],
        },
        {
          key: "3",
          //   icon: <CircleIcon />,
          content:
            "item3 elementum urna varius augue ultrices gravida malesuada fames",
          menu: [
            { key: "1", content: "item3.1" },
            { key: "2", content: "item3.2" },
          ],
        },
      ],
    },
  },
  {
    key: "MenuItem4",
    content: "MenuItem4",
    menu: {
      items: [
        { key: "1", content: "item1" },
        {
          key: "2",
          //   icon: <CircleIcon />,
          content: "item2 non augue tortor mollis",
          menu: [
            { key: "1", content: "Hello World" },
            { key: "2", content: "Hello World 2" },
          ],
        },
        {
          key: "3",
          //   icon: <CircleIcon />,
          content:
            "item3 elementum urna varius augue ultrices gravida malesuada fames",
          menu: [
            { key: "1", content: "This is another paragraph" },
            { key: "2", content: "This is also some paragraph" },
          ],
        },
      ],
    },
  },
];


const NavBar = () => {
  return (
    <>
    
  
      <Menu defaultActiveIndex={0} items={items} 
      ></Menu>
      <Setting/>
      
      

      
    </>
        )
};

export default NavBar;





