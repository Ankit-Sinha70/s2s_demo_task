import React from 'react'
import NavBar from './NavBar'

const SideBar = () => {
  return (
    <>
    
    <NavBar/>
    
    </>
  )
}

export default SideBar