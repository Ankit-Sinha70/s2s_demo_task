import React from "react";
import Home from "../pages/Home";
import Contact from "../pages/Contact";
import { Routes, Route, NavLink } from "react-router-dom";
import About from "../pages/About";
const APPRoute = () => {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />,
        <Route path="/contact" element={<Contact />} />,
        <Route path="/about" element={<About/>} />
      </Routes>
        {/* <NavLink to="/">Home</NavLink>
        <NavLink to="/contact">Contact</NavLink>
        <NavLink to="/about">About</NavLink> */}
    </>
  );
};

export default APPRoute;
