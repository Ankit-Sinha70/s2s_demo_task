import { ContactCardIcon, FlagIcon, MenuIcon, TenantPersonalIcon } from '@fluentui/react-icons-northstar'
import React from 'react'
import {NavLink} from 'react-router-dom'

export const SideBarData = [
    {
        title:"Home",
        path:"/",
        icon:<TenantPersonalIcon />
    },
    {
        title: "About Us",
        path: "/about",
        icon:<FlagIcon />
        },
        {
            title: "Contact us",
            path: "/contact",
            icon:<ContactCardIcon />
            },
]
